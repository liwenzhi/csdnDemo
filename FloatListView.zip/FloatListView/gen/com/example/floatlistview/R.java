/*___Generated_by_IDEA___*/

package com.example.floatlistview;

/* This stub is for using by IDE only. It is NOT the R class actually packed into APK */
public final class R {
}